library(testthat)
library(QALY)

test_check("QALY")
